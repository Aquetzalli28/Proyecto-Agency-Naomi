﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Agency.Data.Entities;
using Agency.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace Agency.Web.Controllers
{
    public class AccountController : Controller
    {
        private IUsersService svc;
        public AccountController(IUsersService svc)
        {
            this.svc = svc;
        }

        [AllowAnonymous]
        public IActionResult LogIn()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> LogIn(LogInViewModel vm)
        {
            // Verificamos si el usuario existe en la base de datos solo por email (sin verificar contraseña)
            User user = await svc.GetUserByEmail(vm.Email);
            if (user != null)
            {
                // Si el usuario está inactivo
                if (user.InactiveDate != null)
                {
                    ModelState.AddModelError("", "El usuario se encuentra dado de baja");
                    return View(vm);
                }

                // Si el usuario existe y no está inactivo, iniciamos sesión
                return await Claims(user.UserId, vm.ReturnUrl);
            }

            // Si el usuario no se encuentra en la base de datos
            ModelState.AddModelError("", "Usuario no encontrado");
            return View(vm);
        }

        [AllowAnonymous]
        private async Task<IActionResult> Claims(int userId, string returnUrl)
        {
            // Obtenemos el usuario por ID
            UserViewModel user = await svc.GetUserById(userId);

            // Creamos las claims para la autenticación
            var claims = new List<Claim>
            {
                new Claim("UserId", user.UserId.ToString(), ClaimValueTypes.Integer),
                new Claim("Name", user.Name)
            };

            var claimsIdentity = new ClaimsIdentity(claims, "Agency.Web");

            // Iniciamos sesión con las claims
            await HttpContext.SignInAsync("Agency.Web", new ClaimsPrincipal(claimsIdentity));

            // Si hay una URL de retorno, redirigimos a ella
            if (returnUrl != null && Url.IsLocalUrl(returnUrl))
            {
                return LocalRedirect(returnUrl);
            }

            // Si no hay URL de retorno, redirigimos al Dashboard (o la página que desees)
            return RedirectToAction("Dashboard", "Home");
        }
    }
}



